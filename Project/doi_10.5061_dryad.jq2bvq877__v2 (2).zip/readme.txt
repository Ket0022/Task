The file consists of three datasets:

mortality, which contains the status (0 - lived, 1 - died) of larvae used in the experiment;

simulation, which contains the following three dependent values: 
							mass_prior (body mass of larvae before the experiment);
							days_active (number of activity days during the simulation);
							change_mass (body mass change over the simulation);

molting, which contains the number of days to molt after the simulation, in the second instar larvae;

and overwinter, which contains the final body mass of the third instar larvae at the time when the experiment was terminated.